package com.example.ostad_exam_live

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
